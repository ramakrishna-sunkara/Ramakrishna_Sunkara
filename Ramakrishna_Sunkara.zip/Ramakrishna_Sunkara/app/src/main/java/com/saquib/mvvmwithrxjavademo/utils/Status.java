package com.saquib.mvvmwithrxjavademo.utils;

/**
 * Created by ${Saquib} on 03-05-2018.
 */

public enum Status {
    LOADING,
    SUCCESS,
    ERROR
}