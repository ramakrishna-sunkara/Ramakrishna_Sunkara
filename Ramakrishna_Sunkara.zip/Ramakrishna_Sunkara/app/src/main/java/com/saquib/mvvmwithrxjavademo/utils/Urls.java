package com.saquib.mvvmwithrxjavademo.utils;

/**
 * Created by ${Saquib} on 03-05-2018.
 */

public class Urls {
    public static final String BASE_URL = "http://xyz/";//put your base url here

    public static final String LOGIN = "abc";//put your end point here

}
